// Write a C program to print "Hello, World!" on the screen.
#include<stdio.h>
main()
{
    printf("Hello World!");
}