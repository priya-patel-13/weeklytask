// Write a C program to add two numbers entered by the user and print the result.

#include<stdio.h>
main()
{
    int a,b;

    printf("\nEnter a:");
    scanf("%d",&a);

    printf("\nEnter b:");
    scanf("%d",&b);

    printf("\na=%d",a);
    printf("\nb=%d",b);
}