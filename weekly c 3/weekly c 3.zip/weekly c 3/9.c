// Write a C program to find the sum of digits of a number entered by the user.

#include<stdio.h>
main()
{
    int a,b,c;

    printf("\nEnter a:");
    scanf("%d",&a);
    
    printf("\nEnter b:");
    scanf("%d",&b);

    c=a+b;

    printf("\n the sum=%d",c);

}